//
//  BSprojectApp.swift
//  BSproject
//
//  DocumentGroup, Window, WKNotificationScene, MenuBarExtra, Settings, WindowGroup= ye all scene hai
//
import SwiftUI

@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
            SplashView()
        }
    }
}


