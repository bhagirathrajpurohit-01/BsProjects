//
//  Celebrity.swift
//  BSproject
//
// 
//

import SwiftUI

struct Celebrity: View {
     var viewModel = CelebViewModel()
  @ObservedObject var celebrityVM: HistoryTrashViewModel
    
    let columns = [GridItem(),
                   GridItem(),]
    
    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVGrid(columns: columns) {
                    ForEach(viewModel.users) { celeb in

                        NavigationLink(
                            destination: CelebDetailView(celeb: celeb)
                                .onAppear {
                                    celebrityVM.addCelebrity(celeb)
                                }
                        ) {
                            VStack {
                                if let url = URL(string: celeb.celebImageUrl) {
                                    AsyncImage(url: url) { image in
                                        image.resizable()
                                            .frame(width: 130, height: 150)
                                            .cornerRadius(12)
                                    } placeholder: {
                                        Image(systemName: "person.crop.rectangle")
                                            .resizable()
                                            .frame(width: 130, height: 120)
                                            .foregroundColor(.gray.opacity(0.6))
                                    }
                                }
                                
                                Text(celeb.celebName)
                                    .font(.headline)
                                    .foregroundColor(.black)
                                    
                            }
                            .padding(.vertical)
                            .frame(width: 170, height: 210)
                            .background(Color.white)
                            .cornerRadius(12)
                            .shadow(radius: 3)
                            
                        }
                        
                    }
                }
                .padding()
            }
            .navigationTitle("Celebrity")
        }
       
        
        
    }
}
#Preview{
    Celebrity(celebrityVM: HistoryTrashViewModel())
}
