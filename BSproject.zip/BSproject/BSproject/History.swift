//
//  History.swift
//  BSproject
//
//  
//
import SwiftUI
struct HistoryView: View {
   @ObservedObject  var historyVM: HistoryTrashViewModel
    
    var body: some View {
        NavigationStack {
            List {
                ForEach(historyVM.history) { item in
                    if let jobTitle = item.jobTitle, !jobTitle.isEmpty {
                        //  Celebrity item
                        let celeb = Celebrityjson(
                            id: item.id,
                            celebName: item.title,
                            celebImageUrl: item.imageUrl!,//force unwrap
                            celebJobTitle: jobTitle,
                            details: item.details!
                        )
                        
                        NavigationLink(destination: CelebDetailView(celeb: celeb)) {
                            HStack {
                                if let imageUrl = item.imageUrl, !imageUrl.isEmpty {
                                    let url = URL(string: imageUrl)
                                    AsyncImage(url: url) { image in
                                        image.resizable()
                                            .frame(width: 70, height: 70)
                                            .clipShape(Circle())
                                            .overlay {
                                                Circle().stroke(.blue, lineWidth: 4)
                                                       }
                                    } placeholder: {
                                        
                                        Image(systemName: "person.fill")
                                            .resizable()
                                            .frame(width: 70, height: 70)
                                            .background(.gray)
                                            .clipShape(Circle())
                                    }
                                }
                                Text(item.title)
                                    .font(.headline)
                                
                            }
                        }
                        
                    } else {
                        //  University item (no navigation)
                        Button(action: {
                            if let firstWeb = item.webPages {
                                let url = URL(string: firstWeb)
                                UIApplication.shared.open(url!)//force unwrap
                            }
                        }) {
                                Text(item.title)
                                    .font(.headline)
                                    .padding(.vertical, 10)
                            
                            
                        }
                    }
                }
                .onDelete(perform: historyVM.deleteFromHistory)
            }
            .navigationTitle("History")
            
        }
    }
}
