//
//  View.swift
//  BSproject
//

import SwiftUI


struct Views: View {
    
    @StateObject var historyTrashVM = HistoryTrashViewModel()
    
    var body: some View {
        
        TabView {
           
                HomeView(homeVM: historyTrashVM)
            .tabItem{
                Image(systemName: "house.fill")
                Text("Home")
            }
            
           
                Celebrity(celebrityVM: historyTrashVM)
            .tabItem{
                Image(systemName: "person.crop.circle")
                Text("Celebrity")
            }
            
           
                HistoryView(historyVM: historyTrashVM)
            .tabItem{
                Image(systemName: "clock")
                Text("History")
            }
            
           
               TrashView(trashVM: historyTrashVM)
            .tabItem{
                Image(systemName: "trash")
                Text("Trash")
            }
        }
        .accentColor(.black)
        
    }
    
}

#Preview {
    Views()
}
