//
//  CelebrityDeteils.swift
//  BSproject
//
// 
//
import SwiftUI

struct CelebDetailView: View {
    var celeb: Celebrityjson
    var body: some View {
        NavigationStack {
            ScrollView{
                VStack {
                    if let url = URL(string: celeb.celebImageUrl) {
                        AsyncImage(url: url) { image in
                            image.resizable()
                                .frame( width: 200, height: 200)
                                .cornerRadius (16)
                                .padding()
                        } placeholder: {
                            Image(systemName: "person.crop.rectangle")
                                .resizable()
                                .frame(width: 200, height: 200)
                                .foregroundColor(.gray.opacity(0.6))
                                .padding()
                        }
                    }
                    
                        Text(celeb.celebName)
                            .font(.largeTitle)
                            .fontWeight(.bold)
                            .lineLimit(nil)
    
                 
                   Text(celeb.celebJobTitle)
                       .font(.title2)                        .foregroundColor(.gray)
                      .lineLimit(nil)
                     .padding()
                    
                   Text(celeb.details)
                        .font(.body)
                        .lineLimit(nil)
                        .padding()
                }
                
                .navigationTitle("Details")
            }
        }
    }
}
