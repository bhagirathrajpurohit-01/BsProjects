import Foundation
import SwiftUI
import SQLite
import Reachability

class CelebViewModel {
     var users: [Celebrityjson] = []

    init() {
        loadUsers()
    }
    
    func loadUsers() {
        if let url = Bundle.main.url(forResource: "user", withExtension: "json") {// find json file location
            do {
                let data = try Data(contentsOf: url)
                let decodedUsers = try JSONDecoder().decode([Celebrityjson].self, from: data)
                self.users = decodedUsers
                
            } catch {
                print("Error decoding JSON")
            }
        }
    }
}

class UniversityViewModel: ObservableObject {
    @Published var universities: [UniversityApi] = []
     @Published var errorMessage: String? = nil   //error message state
     var reachability: Reachability?

    init() {
        setupReachability()
        let cached = DBManager.shared.fetchUniversities()
        if cached.isEmpty {
            fetchUniversity()
        } else {
            self.universities = cached
            print(" This data come from Database = \(cached.count)")
        }
        
    }
        
    // Api se data fetch 
    func fetchUniversity() {
        
        if let url = URL(string: "http://universities.hipolabs.com/search?country=United+States&limit=950&offset=0") {
           
            URLSession.shared.dataTask(with : url) { data, response, error in
                
                if let data = data {
                    do {
                        let decodedData = try JSONDecoder().decode([UniversityApi].self, from: data)
                        DispatchQueue.main.async {
                            self.universities = decodedData
                            print("this data come from api = \(self.universities.count)")
                            DBManager.shared.insertUniversities(decodedData)
                        }
                    } catch {
                            self.errorMessage = "Error decoding data"
                    }
                }
            }.resume()// request ko chalane ke liye hamesha .resume() lagana padta hai.
        }
    }
   func setupReachability() {
       reachability = try? Reachability()
       
       //  Internet Unavailable
      reachability?.whenUnreachable = { _ in
               self.errorMessage = "No Internet Connection"
       }
          
          //  Internet available
       reachability?.whenReachable = { _ in
           if self.universities.isEmpty == true && self.errorMessage ==  "No Internet Connection"{
               self.fetchUniversity()
           }
       }
                   
         try? reachability?.startNotifier()//detect internet connection if internet == true whenReachable false= whenUnreachable
     }
   }




class HistoryTrashViewModel: ObservableObject {
    @Published var history: [HistoryTrashItem] = []
    @Published var trash: [HistoryTrashItem] = []
    @Published var showRestoreAlert: Bool = false
    var selectedTrashItem: HistoryTrashItem? = nil
    init() {
        self.history = DBManager.shared.fetchHistory()
        self.trash = DBManager.shared.fetchTrash()
    }
    
    func addCelebrity(_ celeb: Celebrityjson) {
        let item = HistoryTrashItem(
            title: celeb.celebName,
            imageUrl: celeb.celebImageUrl,
            jobTitle: celeb.celebJobTitle,
            details: celeb.details
        )
        history.removeAll { name in
            name.title == item.title }
        history.insert(item, at: 0)
        DBManager.shared.insertHistoryItem(item)
    }
    
    func addUniversity(_ uni: UniversityApi) {
        let item = HistoryTrashItem(
            title: uni.name,
            webPages: uni.web_pages.joined(separator: ",")
        )
        history.removeAll { name in
            name.title == item.title }
        history.insert(item, at: 0)
        DBManager.shared.insertHistoryItem(item)
    }
    
    func deleteFromHistory(offsets: IndexSet) {
        if let firstindex = offsets.first {
            var item = history[firstindex]
            item.originalIndex = firstindex
            trash.removeAll { name in
                name.title == item.title }
            trash.insert(item, at: 0)
            
            DBManager.shared.insertTrashItem(item)
            DBManager.shared.deleteHistoryItem(item)
            history.remove(atOffsets: offsets)
        }
    }

    func restoreFromTrash(_ item: HistoryTrashItem) {
        // Simple duplicate check
        if history.contains(where: { name in
            name.title == item.title }) {
            selectedTrashItem = item
            showRestoreAlert = true
        } else {
            insertItemInHistory(item)
            
        }
    }
    
    func handleRestoreAction(restore: Bool) {
        if let item = selectedTrashItem {
            if restore {
                history.removeAll { name in
                    name.title == item.title }
            }
            insertItemInHistory(item)
            selectedTrashItem = nil
        }
    }

    
    func insertItemInHistory(_ item: HistoryTrashItem) {
        if let index = item.originalIndex,
           index <= history.count {
            history.insert(item, at: index)
        } else {
            // agar index invalid hai to top pe daal do
            history.insert(item, at: 0)
        }
        
        DBManager.shared.restoreTrashItem(item)
        
        if let trashIndex = trash.firstIndex(where: { nameid in
            nameid.id == item.id }) {
            trash.remove(at: trashIndex)
        }
    }

    
    func permanentlyDeleteFromTrash(_ index: Int) {
        let item = trash[index]
        DBManager.shared.deleteTrashItem(item)
        trash.remove(at: index)
    }
}
