//
//  Trash.swift
//  BSproject
//
//
//

import SwiftUI

struct TrashView: View {
    @ObservedObject var trashVM: HistoryTrashViewModel
    
    var body: some View {
        NavigationStack {
            List(trashVM.trash) { item in
                HStack {
                    if let imageUrl = item.imageUrl {
                        let url = URL(string: imageUrl)
                        AsyncImage(url: url) { image in
                            image.resizable()
                                .frame(width: 50, height: 50)
                                .clipShape(Circle())
                                .overlay {
                                    Circle().stroke(.blue, lineWidth: 4)
                                           }
                        } placeholder: {
                            Image(systemName: "person.crop.circle.fill")
                                .resizable()
                                .frame(width: 50, height: 50)
                                .foregroundColor(.gray)
                        }
                    }
                    Text(item.title)
                        .font(.headline)
                    
                }
                .padding(.vertical, 6)
                .swipeActions(edge: .trailing) {
                    Button(role: .destructive) {
                        if let index = trashVM.trash.firstIndex(where: { itemId in
                            itemId.id == item.id }) {
                            trashVM.permanentlyDeleteFromTrash(index)
                        }
                    } label: {
                        Image(systemName: "trash")
                    }
                    
                    Button {
                        trashVM.restoreFromTrash(item)
                    } label: {
                        Image(systemName: "arrow.uturn.backward")
                    }
                    .tint(.blue)
                }
                
            }
            .navigationTitle("Trash")
            
            
            .alert("Item already exists in History", isPresented: $trashVM.showRestoreAlert) {
                Button("restore") {
                    trashVM.handleRestoreAction(restore: true)
                }
                Button("Cancel", role: .cancel) { }
                
            } message: {
                Text("What would you like to do?")
            }
            
        }
    }
    
}
