//
//  DatabaseManager.swift
//  BSproject
//SQLite database column (like webPages) cannot store an array directly —
//it can only store a single value per column (like String, Int, etc).

import Foundation
import SQLite

class DBManager {
    static let shared = DBManager()
    var db: Connection?

    // Tables
    let universitiesTable = Table("universities")
    let historyTable = Table("history")
    let trashTable = Table("trash")

    // Columns
    let id = Expression<String>("id")
    let name = Expression<String>("name")
    let imageUrl = Expression<String?>("imageUrl")
    let country = Expression<String?>("country")
    let domains = Expression<String?>("domains")
    let webPages = Expression<String?>("webPages")
    let jobTitle = Expression<String?>("jobTitle")
    let details = Expression<String?>("details")
    let originalIndex = Expression<Int?>("originalIndex")
    let createdAt = Expression<Date>("createdAt")
    
     private init() {
        setupDatabase()
    }

    func setupDatabase() {
        do {//libraryDirectory,cachesDirectory, documentDirectory
            let path = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
            print("Database path: \(path)")
            db = try Connection("\(path)/app.sqlite3")// object create

            // Universities
            try db?.run(universitiesTable.create(ifNotExists: true) { t in
                t.column(id)
                t.column(name)
                t.column(country)
                t.column(domains)
                t.column(webPages)
            })

            // History
            try db?.run(historyTable.create(ifNotExists: true) { t in
                t.column(id)
                t.column(name, unique: true)
                t.column(imageUrl)
                t.column(jobTitle)
                t.column(details)
                t.column(webPages)
                t.column(createdAt)
               
            })

            // Trash
            try db?.run(trashTable.create(ifNotExists: true) { t in
                t.column(id)
                t.column(name, unique: true)
                t.column(imageUrl)
                t.column(jobTitle)
                t.column(details)
                t.column(webPages)
                t.column(createdAt)
                t.column(originalIndex)
                
               
            })

        } catch {
            print("DB Error")
        }
    }
    // Universities
    func insertUniversities(_ universities: [UniversityApi]) {
        do {
            for uni in universities {
                try db?.run(universitiesTable.insert(or: .replace,
                                id <- uni.id,
                                name <- uni.name,
                                country <- uni.country,
                                domains <- uni.domains.joined(separator: ","),// array of string ko single string me convert
                                webPages <- uni.web_pages.joined(separator: ",")))
            }
        } catch {
            print("Insert Universities Error")
        }
    }

    func fetchUniversities() -> [UniversityApi] {
        var result: [UniversityApi] = []
        do {
            if let rows = try db?.prepare(universitiesTable) {
                for row in rows {
                    let uni = UniversityApi(
                        id: row[id],// row ke inside id column mai uski value id mai assign karna
                        name: row[name],
                        country: row[country] ?? "",// row mai country column hai uski value councry mai assign kar doAgar database me country nil hai (means blank / missing value),to app crash na kare, uske liye hum default value dete hain — empty string "".
                        domains: row[domains]?.components(separatedBy: ",") ?? [],
                        web_pages: row[webPages]?.components(separatedBy: ",") ?? []
                    )
                    result.append(uni)
                    
                }
            }
        } catch { print("Fetch Universities Error") }
        return result
    }

    // History
    func insertHistoryItem(_ item: HistoryTrashItem) {
        do {
            try db?.run(historyTable.insert(or: .replace,
                                            id <- item.id,
                                            name <- item.title,
                                            imageUrl <- item.imageUrl,
                                            jobTitle <- item.jobTitle,
                                            details <- item.details,
                                            webPages <- item.webPages,
                                            createdAt <- Date()
                                           
                                           ))
        } catch {
            print("Insert History Error")
        }
    }

    func fetchHistory() -> [HistoryTrashItem] {
        var result: [HistoryTrashItem] = []
        do {
            if let rows = try db?.prepare(historyTable.order(createdAt.desc)) {//descending order
                for row in rows {
                    let item = HistoryTrashItem(
                        id: row[id],
                        title: row[name],
                        imageUrl: row[imageUrl],
                        jobTitle: row[jobTitle],
                        details: row[details],
                        webPages: row[webPages]
                    )
                    result.append(item)
                }
            }
        } catch { print("Fetch History Error") }
        return result
    }

    func deleteHistoryItem(_ item: HistoryTrashItem) {
        do {
            let row = historyTable.filter(id == item.id)
            try db?.run(row.delete())
        } catch { print("Delete History Error") }
    }

    //  Trash
    func insertTrashItem(_ item: HistoryTrashItem) {
        do {
            try db?.run(trashTable.insert(or: .replace,
                                          id <- item.id,
                                          name <- item.title,
                                          imageUrl <- item.imageUrl,
                                          jobTitle <- item.jobTitle,
                                          details <- item.details,
                                          webPages <- item.webPages,
                                          originalIndex <- item.originalIndex,
                                          createdAt <- Date()
                                          
                                        ))
        } catch {
            print("Insert Trash Error")
        }
    }

    func fetchTrash() -> [HistoryTrashItem] {
        var result: [HistoryTrashItem] = []
        do {
            if let rows = try db?.prepare(trashTable.order(createdAt.desc)) {
                for row in rows {
                    let item = HistoryTrashItem(
                        id: row[id],
                        title: row[name],
                        imageUrl: row[imageUrl],
                        originalIndex: row[originalIndex],
                        jobTitle: row[jobTitle],
                        details: row[details],
                        webPages: row[webPages]
                    )
                    result.append(item)
                }
            }
        } catch {
            print("Fetch Trash Error")
        }
        return result
    }

    func deleteTrashItem(_ item: HistoryTrashItem) {
        do {
            let row = trashTable.filter(id == item.id)
            try db?.run(row.delete())
        } catch { print("Delete Trash Error") }
    }

    func restoreTrashItem(_ item: HistoryTrashItem) {
            insertHistoryItem(item)
        deleteTrashItem(item)
        
    }
}
