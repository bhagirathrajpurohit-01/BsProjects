//
//  SplashView.swift
//  BSproject
//
//
//

import SwiftUI
import AVFoundation

struct SplashView: View {
    @State var isActive = false
    @State var audioPlayer: AVAudioPlayer?

    var body: some View {
        if isActive {
            Views() // Main screen
                .onAppear {
                    stopSound() // Splash close → stop audio
                }
        } else {
            ZStack{
                Color.black.ignoresSafeArea() //Status Bar(Time, Network signal, Wi-Fi icon, Battery level), Toolbar(tabs(home, celebrity its))
                Image("SplashImage")
                    .resizable()
                    .scaledToFit()
            }
                .onAppear {
                    playSound()
                    // Navigate to main screen after 2 seconds
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2) {// future delay
                        isActive = true
                    }
                }
        }
    }
    
     func playSound() {
        if let soundURL = Bundle.main.url(forResource: "music", withExtension: "mp3") {
            do {
                audioPlayer = try AVAudioPlayer(contentsOf: soundURL)
                audioPlayer?.play()
                audioPlayer?.volume = 1.0
                //audioPlayer?.enableRate = true
                //audioPlayer?.rate = 2.0 music speed 2x
                
                
            } catch {
                print(" Error playing sound ")
            }
        }
         
    }
    
    func stopSound() {
            audioPlayer?.stop()
        }
}

#Preview {
    SplashView()
}
