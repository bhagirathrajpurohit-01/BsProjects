//
//  Model.swift
//  BSproject
//
//  
//

    import Foundation


    // Celebrity Model
    struct Celebrityjson: Codable,Identifiable {
        var id = UUID().uuidString
        let celebName: String
        let celebImageUrl: String
        let celebJobTitle: String
        let details: String
        
        enum CodingKeys: CodingKey {
            case celebName, celebImageUrl, celebJobTitle, details
        }
    }

    // University Model
    struct UniversityApi: Codable, Identifiable {
        var id = UUID().uuidString
        let name: String
        let country: String
        let domains: [String]
        let web_pages: [String]
        
        enum CodingKeys: CodingKey {
            case name, country, domains, web_pages
        }
    }

    // History & Trash Model
    struct HistoryTrashItem: Identifiable {
        var id = UUID().uuidString
        var title: String
        var imageUrl: String?
        var originalIndex: Int?
        var jobTitle: String?
        var details: String?
        var webPages: String?
    }
