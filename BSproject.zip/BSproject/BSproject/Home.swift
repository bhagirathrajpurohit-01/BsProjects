//
//  Home.swift
//  BSproject

import SwiftUI

struct HomeView: View {
    @StateObject var viewModel = UniversityViewModel()
    @ObservedObject var homeVM: HistoryTrashViewModel
    @State var searchText = ""
    
    var filteredUniversities: [UniversityApi] {
        if searchText.isEmpty {
            return viewModel.universities
        } else {
            return viewModel.universities.filter { item in// current
               item.name.localizedCaseInsensitiveContains(searchText)
            }
        }
    }
    
    var body: some View {
        NavigationStack {
            VStack {
                if let error = viewModel.errorMessage, viewModel.universities.isEmpty {
                    
                    Image(systemName: "wifi.slash")
                        .font(.largeTitle)
                        .foregroundColor(.red)
                        .padding()
                    Text(error)
                        .font(.largeTitle)
                        .foregroundColor(.red)
                    
                } else {
                    
                    // Universities list
                    List(filteredUniversities) { uni in
                       
                            Text(uni.name)
                                .font(.headline)
                        
                            Text("Domains: \(uni.domains.joined(separator: ", "))")
                                .font(.subheadline)
                                .foregroundColor(.purple)
                            .padding(.vertical, 6)
                            .onTapGesture {
                                homeVM.addUniversity(uni)
                                if let firstWeb = uni.web_pages.first,
                                   let url = URL(string: firstWeb) {
                                    UIApplication.shared.open(url)// open url in safari
                                }
                            }
                    }
                    .navigationTitle("Universities")
                    .searchable(text: $searchText, prompt: "Search universities")// user input ke saath state update kare.
                }
            }
                }
            }
        }
        
    
#Preview{
    HomeView(homeVM: HistoryTrashViewModel())
}

